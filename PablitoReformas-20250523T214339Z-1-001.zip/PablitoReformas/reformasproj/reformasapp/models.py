from django.db import models
from django.utils import timezone

class ContatoSolicitacao(models.Model):
    nome = models.CharField(max_length=100)
    email = models.EmailField()
    telefone = models.CharField(max_length=20)
    assunto = models.CharField(max_length=200)
    mensagem = models.TextField()
    data_criacao = models.DateTimeField(default=timezone.now)
    respondido = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'Solicitação de Contato'
        verbose_name_plural = 'Solicitações de Contato'
        ordering = ['-data_criacao']

    def __str__(self):
        return f'{self.nome} - {self.assunto}'

class ServicoReforma(models.Model):
    TIPOS_SERVICO = [
        ('pintura', 'Pintura'),
        ('eletrica', 'Elétrica'),
        ('hidraulica', 'Hidráulica'),
        ('alvenaria', 'Alvenaria'),
        ('pisos', 'Pisos e Revestimentos'),
        ('telhado', 'Telhados'),
        ('jardim', 'Jardins e Paisagismo'),
        ('completa', 'Reforma Completa'),
    ]
    
    nome = models.CharField(max_length=100)
    tipo = models.CharField(max_length=20, choices=TIPOS_SERVICO)
    descricao = models.TextField()
    preco_base = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    ativo = models.BooleanField(default=True)

    class Meta:
        verbose_name = 'Serviço de Reforma'
        verbose_name_plural = 'Serviços de Reforma'

    def __str__(self):
        return self.nome