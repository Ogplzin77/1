from django.test import TestCase, Client
from django.urls import reverse
from django.core import mail
from reformas.models import Contato
from reformas.forms import ContatoForm


class ContatoModelTest(TestCase):
    """Testes para o modelo Contato"""
    
    def setUp(self):
        self.contato = Contato.objects.create(
            nome='João Silva',
            email='joao@email.com',
            telefone='11999999999',
            tipo_servico='reforma_completa',
            endereco='Rua Teste, 123',
            mensagem='Preciso reformar minha casa'
        )
    
    def test_contato_creation(self):
        """Testa a criação de um contato"""
        self.assertEqual(self.contato.nome, 'João Silva')
        self.assertEqual(self.contato.email, 'joao@email.com')
        self.assertEqual(self.contato.telefone, '11999999999')
        self.assertEqual(self.contato.tipo_servico, 'reforma_completa')
        self.assertFalse(self.contato.respondido)
    
    def test_contato_str_method(self):
        """Testa o método __str__ do modelo"""
        expected_str = f"João Silva - joao@email.com"
        self.assertEqual(str(self.contato), expected_str)
    
    def test_contato_ordering(self):
        """Testa a ordenação dos contatos"""
        contato2 = Contato.objects.create(
            nome='Maria Santos',
            email='maria@email.com',
            telefone='11888888888',
            mensagem='Teste'
        )
        
        contatos = Contato.objects.all()
        # O mais recente deve vir primeiro
        self.assertEqual(contatos.first(), contato2)


class ContatoFormTest(TestCase):
    """Testes para o formulário de contato"""
    
    def test_valid_form(self):
        """Testa formulário válido"""
        form_data = {
            'nome': 'João Silva',
            'email': 'joao@email.com',
            'telefone': '11999999999',
            'tipo_servico': 'reforma_completa',
            'endereco': 'Rua Teste, 123',
            'mensagem': 'Preciso reformar minha casa'
        }
        form = ContatoForm(data=form_data)
        self.assertTrue(form.is_valid())
    
    def test_form_missing_required_fields(self):
        """Testa formulário com campos obrigatórios faltando"""
        form_data = {
            'nome': '',
            'email': 'joao@email.com',
            'telefone': '',
            'mensagem': ''
        }
        form = ContatoForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('nome', form.errors)
        self.assertIn('telefone', form.errors)
        self.assertIn('mensagem', form.errors)
    
    def test_invalid_email(self):
        """Testa email inválido"""
        form_data = {
            'nome': 'João Silva',
            'email': 'email_invalido',
            'telefone': '11999999999',
            'mensagem': 'Teste'
        }
        form = ContatoForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('email', form.errors)


class ViewsTest(TestCase):
    """Testes para as views"""
    
    def setUp(self):
        self.client = Client()
    
    def test_inicio_view(self):
        """Testa a view da página inicial"""
        response = self.client.get(reverse('inicio'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'ReformasPro')
    
    def test_servicos_view(self):
        """Testa a view da página de serviços"""
        response = self.client.get(reverse('servicos'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Nossos Serviços')
    
    def test_quem_somos_view(self):
        """Testa a view da página quem somos"""
        response = self.client.get(reverse('quem_somos'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Nossa História')
    
    def test_contato_view_get(self):
        """Testa a view de contato com GET"""
        response = self.client.get(reverse('contato'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Entre em Contato')
        self.assertIsInstance(response.context['form'], ContatoForm)
    
    def test_contato_view_post_valid(self):
        """Testa a view de contato com POST válido"""
        form_data = {
            'nome': 'João Silva',
            'email': 'joao@email.com',
            'telefone': '11999999999',
            'tipo_servico': 'reforma_completa',
            'endereco': 'Rua Teste, 123',
            'mensagem': 'Preciso reformar minha casa'
        }
        
        response = self.client.post(reverse('contato'), data=form_data)
        
        # Verifica se foi criado um contato
        self.assertEqual(Contato.objects.count(), 1)
        
        # Verifica se foi enviado email
        self.assertEqual(len(mail.outbox), 1)
        
        # Verifica redirecionamento
        self.assertEqual(response.status_code, 302)
    
    def test_contato_view_post_invalid(self):
        """Testa a view de contato com POST inválido"""
        form_data = {
            'nome': '',
            'email': 'email_invalido',
            'telefone': '',
            'mensagem': ''
        }
        
        response = self.client.post(reverse('contato'), data=form_data)
        
        # Não deve criar contato
        self.assertEqual(Contato.objects.count(), 0)
        
        # Não deve enviar email
        self.assertEqual(len(mail.outbox), 0)
        
        # Deve retornar o formulário com erros
        self.assertEqual(response.status_code, 200)
        self.assertFormError(response, 'form', 'nome', 'Este campo é obrigatório.')


class URLsTest(TestCase):
    """Testes para as URLs"""
    
    def test_inicio_url(self):
        """Testa a URL da página inicial"""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_servicos_url(self):
        """Testa a URL da página de serviços"""
        response = self.client.get('/servicos/')
        self.assertEqual(response.status_code, 200)
    
    def test_quem_somos_url(self):
        """Testa a URL da página quem somos"""
        response = self.client.get('/quem-somos/')
        self.assertEqual(response.status_code, 200)
    
    def test_contato_url(self):
        """Testa a URL da página de contato"""
        response = self.client.get('/contato/')
        self.assertEqual(response.status_code, 200)
    
    def test_url_names(self):
        """Testa os nomes das URLs"""
        self.assertEqual(reverse('inicio'), '/')
        self.assertEqual(reverse('servicos'), '/servicos/')
        self.assertEqual(reverse('quem_somos'), '/quem-somos/')
        self.assertEqual(reverse('contato'), '/contato/')


class IntegrationTest(TestCase):
    """Testes de integração"""
    
    def setUp(self):
        self.client = Client()
    
    def test_navigation_flow(self):
        """Testa o fluxo de navegação entre páginas"""
        # Início
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        
        # Serviços
        response = self.client.get('/servicos/')
        self.assertEqual(response.status_code, 200)
        
        # Quem Somos
        response = self.client.get('/quem-somos/')
        self.assertEqual(response.status_code, 200)
        
        # Contato
        response = self.client.get('/contato/')
        self.assertEqual(response.status_code, 200)
    
    def test_contact_form_integration(self):
        """Testa a integração completa do formulário de contato"""
        # Acessa a página de contato
        response = self.client.get('/contato/')
        self.assertEqual(response.status_code, 200)
        
        # Preenche e envia o formulário
        form_data = {
            'nome': 'João Silva',
            'email': 'joao@email.com',
            'telefone': '11999999999',
            'tipo_servico': 'reforma_completa',
            'endereco': 'Rua Teste, 123',
            'mensagem': 'Preciso reformar minha casa'
        }
        
        response = self.client.post('/contato/', data=form_data, follow=True)
        
        # Verifica se o contato foi salvo
        contato = Contato.objects.first()
        self.assertIsNotNone(contato)
        self.assertEqual(contato.nome, 'João Silva')
        self.assertEqual(contato.email, 'joao@email.com')
        
        # Verifica se foi enviado email
        self.assertEqual(len(mail.outbox), 1)
        email = mail.outbox[0]
        self.assertIn('João Silva', email.body)
        self.assertIn('joao@email.com', email.body)
        
        # Verifica mensagem de sucesso
        messages = list(response.context['messages'])
        self.assertEqual(len(messages), 1)
        self.assertEqual(str(messages[0]), 'Sua mensagem foi enviada com sucesso! Entraremos em contato em breve.')


class AdminTest(TestCase):
    """Testes para o admin"""
    
    def setUp(self):
        from django.contrib.auth.models import User
        self.admin_user = User.objects.create_superuser(
            username='admin',
            email='admin@test.com',
            password='admin123'
        )
        self.client.login(username='admin', password='admin123')
        
        self.contato = Contato.objects.create(
            nome='João Silva',
            email='joao@email.com',
            telefone='11999999999',
            mensagem='Teste'
        )
    
    def test_admin_contato_list(self):
        """Testa a listagem de contatos no admin"""
        response = self.client.get('/admin/reformas/contato/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'João Silva')
    
    def test_admin_contato_detail(self):
        """Testa os detalhes do contato no admin"""
        response = self.client.get(f'/admin/reformas/contato/{self.contato.id}/change/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'João Silva')
        self.assertContains(response, 'joao@email.com')