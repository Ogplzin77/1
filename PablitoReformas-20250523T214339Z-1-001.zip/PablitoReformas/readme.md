# Website de Reformas Prediais

Um website completo para empresa de reformas e manutenção predial, desenvolvido com Django e Bootstrap.

## 🚀 Funcionalidades

- **Página Inicial**: Apresentação da empresa e serviços principais
- **Serviços**: Detalhamento dos tipos de reforma e manutenção oferecidos
- **Quem Somos**: Informações sobre a equipe e visão da empresa
- **Contato**: Formulário de contato e informações para comunicação

## 🛠️ Tecnologias Utilizadas

- **Backend**: Python 3.8+ / Django 4.2+
- **Frontend**: HTML5, CSS3, Bootstrap 5
- **Banco de Dados**: SQLite (desenvolvimento) / PostgreSQL (produção)
- **Estilização**: CSS customizado + Bootstrap

## 📋 Pré-requisitos

- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)
- Git (opcional)

## 🔧 Instalação e Configuração

### 1. Clone o repositório (ou baixe os arquivos)
```bash
git clone [seu-repositorio]
cd projeto-reformas
```

### 2. Crie um ambiente virtual
```bash
# Linux/Mac
python3 -m venv venv
source venv/bin/activate

# Windows
python -m venv venv
venv\Scripts\activate
```

### 3. Instale as dependências
```bash
pip install -r requirements.txt
```

### 4. Configure o banco de dados
```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Crie um superusuário (opcional)
```bash
python manage.py createsuperuser
```

### 6. Colete arquivos estáticos
```bash
python manage.py collectstatic
```

## ▶️ Executando o Projeto

### Modo Desenvolvimento
```bash
python manage.py runserver
```

O site estará disponível em: http://127.0.0.1:8000/

### Acessando o Admin
- URL: http://127.0.0.1:8000/admin/
- Use as credenciais do superusuário criado

## 📁 Estrutura do Projeto

```
projeto_reformas/
├── projeto_reformas/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
├── reformas/
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── forms.py
│   ├── models.py
│   ├── urls.py
│   ├── views.py
│   └── migrations/
├── templates/
│   ├── base.html
│   └── reformas/
│       ├── inicio.html
│       ├── servicos.html
│       ├── quem_somos.html
│       └── contato.html
├── static/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── images/
├── media/
├── manage.py
├── requirements.txt
└── README.md
```

## 🎨 Personalização

### Cores e Estilo
- Edite o arquivo `static/css/style.css` para personalizar cores e estilos
- As cores principais podem ser alteradas nas variáveis CSS no início do arquivo

### Conteúdo
- Textos: Edite os templates em `templates/reformas/`
- Imagens: Adicione em `static/images/` e referencie nos templates

### Funcionalidades
- Modelos: Edite `reformas/models.py`
- Formulários: Edite `reformas/forms.py`
- Lógica: Edite `reformas/views.py`

## 📧 Configuração de Email

Para o formulário de contato funcionar, configure o email em `settings.py`:

```python
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'seu-email@gmail.com'
EMAIL_HOST_PASSWORD = 'sua-senha-app'
```

## 🚀 Deploy (Produção)

### Heroku
1. Instale o Heroku CLI
2. Configure `ALLOWED_HOSTS` em settings.py
3. Configure variáveis de ambiente
4. Deploy com Git

### VPS/Servidor Próprio
1. Configure nginx/apache
2. Use gunicorn como WSGI server
3. Configure SSL (Let's Encrypt)
4. Configure banco PostgreSQL

## 🐛 Solução de Problemas

### Erro de Migração
```bash
python manage.py makemigrations --empty reformas
python manage.py migrate
```

### Arquivos Estáticos não Carregam
```bash
python manage.py collectstatic --clear
```

### Erro de Permissão
- Verifique se o ambiente virtual está ativo
- Verifique permissões da pasta do projeto

## 📞 Suporte

Para dúvidas ou problemas:
- Verifique a documentação do Django: https://docs.djangoproject.com/
- Consulte os logs de erro no terminal
- Verifique as configurações em settings.py

## 📄 Licença

Este projeto é de uso livre para fins educacionais e comerciais.

---

**Desenvolvido com ❤️ para sua empresa de reformas prediais**